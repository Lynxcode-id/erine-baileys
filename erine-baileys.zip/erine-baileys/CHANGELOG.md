# Changelog

## 1.0.0 - 2026-11-10

Initial release of **Erine Baileys** by Lynx decode, forked from Elaina Baileys 1.4.9 (rexxhayanasi).

### Rebrand
- Package renamed to `erine-baileys`; repository `Lynxcode-id/erine-baileys`; author Lynx decode.
- `LICENSE` keeps every upstream copyright line and adds Lia Wynn and Lynx decode. `NOTICE.md` documents the full lineage.
- Credits in README, `NOTICE.md`, the MessageBuilder watermark and the ported Lia notes are preserved.
- Internal names: logger class `erine`, VoIP temp dir `erine-voip`, default NekoDB auth collection `baileys_erine_auth` (was `baileys_elaina_auth`; pass `collectionName` to keep an old one).
- Default sticker pack publisher/description now point to Lynxcode-id.
- `@rexxhayanasi/wangcap-id-bridge` and the optional `@rexxhayanasi/elaina-anchorguard` stay as dependencies.

### Ported from itsliaaa/baileys (Lia Wynn) 0.5.1
- feat: rich response messages: `code`, `table`, `links` and `richResponse` content in `sendMessage()`, `tokenizeCode()` exported.
- feat: media `mimetype` is detected from the file content when it is not provided (falls back to the per-type default).
- feat: `genai_sticker` media type for `stickerMessage` with `isAiSticker`.
- feat: `server_transcode=1` on newsletter video / gif / ptv uploads; newsletter upload falls back to `direct_path` when the server returns no `url`.
- feat: debounced phash mismatch recovery on bad ACK for groups (resets the sender-key memory and relays the cached message once).
- chore: extra entries in `MEDIA_PATH_MAP`, `NEWSLETTER_MEDIA_PATH_MAP` and `MEDIA_HKDF_KEY_MAPPING` (only keys Elaina did not have; existing values untouched).

### Not ported
- The Rust/WASM signal transport (`whatsapp-rust-bridge`) and `@itsliaaa/starforge`: Elaina Baileys keeps `libsignal`. Porting them would replace the crypto/transport layer and is a separate piece of work.
- Lia's `WAProto` and default WA version: Elaina's WAProto is newer/larger and was kept.
