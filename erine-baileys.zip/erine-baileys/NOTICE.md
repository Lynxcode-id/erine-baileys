# Erine Baileys Notices

Erine Baileys is a fork of **Elaina Baileys** (`@rexxhayanasi/elaina-baileys`, by rexxhayanasi), developed and maintained by **Lynx decode** ([github.com/Lynxcode-id](https://github.com/Lynxcode-id)) under the `erine-baileys` package identity.

No credit from the upstream lineage has been removed. The copyright holders listed in `LICENSE` are Rajeh Taher/WhiskeySockets, rexxhayanasi, Lia Wynn and Lynx decode, and the permission notice must stay with every copy of this software.

## Lineage

- **Baileys** — WhiskeySockets/Baileys (Rajeh Taher) and the original work of adiwajshing.
- **itsliaaa/baileys** — Lia Wynn (ItsLia). Elaina Baileys already used the ItsLia lineage as a development base. Erine Baileys additionally ports these features from itsliaaa/baileys v0.5.1: rich response messages (`code`, `table`, `links`, `richResponse`) via `src/Utils/rich-message-utils.js` and `src/Types/RichType.js`, the code-highlight lexer data in `src/Utils/rich-language-keywords.js`, automatic mimetype detection when a media payload has no `mimetype`, the `genai_sticker` media type for `isAiSticker`, `server_transcode` for newsletter video/gif/ptv uploads, debounced phash mismatch recovery on bad ACK, and the extra media upload path / HKDF key entries. Ported files keep Lia Wynn's original notes (for example the `Lia@Note` / `Lia@Changes` comments and the "DO NOT CHANGE THIS NOTE" header in `rich-message-utils.js`) unchanged. `src/Utils/detect-file-type.js` is an Erine reimplementation of the mimetype detection behaviour (itsliaaa/baileys gets it from `@itsliaaa/starforge`).
- **Elaina Baileys** — rexxhayanasi. The base of this fork.
- **MessageBuilder** — NIXCODE / Advanced WhatsApp Interactive Message Builder by Nixel (contributor: Ahmad tumbuh kembang; listed in the README credits together with ValdazGT). Its original watermark and license text in `src/MessageBuilder/index.js` is kept byte-for-byte and must not be removed.
- **VoIP** — `src/Voip/` derives from `baileys-caller` by ShellTear (see the preserved Elaina notice below).

## Elaina Baileys notices (preserved)

# Elaina Baileys Notices

Elaina Baileys is an independently maintained fork/distribution in the Baileys ecosystem.

The upstream copyright and permission notice are preserved in `LICENSE`. Portions of the codebase derive from or were influenced by upstream Baileys work and subsequent forks, including the ItsLia lineage used as a development base.

The integrated MessageBuilder retains its original author/watermark notice in `lib/MessageBuilder/index.js`.

The VoIP calling stack in `lib/Voip/` derives from work by ShellTear, whose `baileys-caller` project first showed the WhatsApp Web VoIP WASM engine could be driven from Node. It has been ported to ESM, reworked to run on the caller's existing socket, and maintained here since. The WhatsApp Web resources it drives are vendored unmodified under `lib/assets/wasm/`, with their provenance, checksums and capability surface described in the README there.

Elaina-specific maintenance, packaging, compatibility changes, integrations, and ongoing development are maintained under the `@rexxhayanasi/elaina-baileys` package identity.
