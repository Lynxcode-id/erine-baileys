/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class CiphertextMessage {
    UNSUPPORTED_VERSION: number;
    CURRENT_VERSION: number;
    WHISPER_TYPE: number;
    PREKEY_TYPE: number;
    SENDERKEY_TYPE: number;
    SENDERKEY_DISTRIBUTION_TYPE: number;
    ENCRYPTED_MESSAGE_OVERHEAD: number;
}
