/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class CiphertextMessage {
    constructor() {
        this.UNSUPPORTED_VERSION = 1;
        this.CURRENT_VERSION = 3;
        this.WHISPER_TYPE = 2;
        this.PREKEY_TYPE = 3;
        this.SENDERKEY_TYPE = 4;
        this.SENDERKEY_DISTRIBUTION_TYPE = 5;
        this.ENCRYPTED_MESSAGE_OVERHEAD = 53;
    }
}
