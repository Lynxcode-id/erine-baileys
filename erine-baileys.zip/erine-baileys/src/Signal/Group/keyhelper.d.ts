/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function generateSenderKey(): any;
export function generateSenderKeyId(): any;
export function generateSenderSigningKey(key: any): {
    public: any;
    private: any;
};
