/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class SenderKeyName {
    constructor(groupId: any, sender: any);
    groupId: any;
    sender: any;
    getGroupId(): any;
    getSender(): any;
    serialize(): string;
    toString(): string;
    equals(other: any): boolean;
    hashCode(): number;
}
