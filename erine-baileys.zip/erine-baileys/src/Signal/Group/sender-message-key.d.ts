/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class SenderMessageKey {
    constructor(iteration: any, seed: any);
    iv: any;
    cipherKey: any;
    iteration: any;
    seed: any;
    getIteration(): any;
    getIv(): any;
    getCipherKey(): any;
    getSeed(): any;
}
