/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class AbstractSocketClient {
    constructor(url: any, config: any);
    url: any;
    config: any;
}
