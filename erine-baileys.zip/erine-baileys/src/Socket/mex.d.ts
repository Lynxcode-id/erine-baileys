/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function executeWMexQuery(variables: any, queryId: any, dataPath: any, query: any, generateMessageTag: any): Promise<any>;
