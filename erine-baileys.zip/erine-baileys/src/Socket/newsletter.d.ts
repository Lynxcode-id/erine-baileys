/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export interface NewsletterAddOnGroup {
    jid?: string;
    messages: {
        serverId?: number;
        reaction?: { code?: string; t?: number };
        pollVote?: { t?: number; hashes: string[] };
    }[];
}
export interface NewsletterEnforcement {
    enforcementId?: string;
    createdAt?: number;
    violationCategory?: string;
    source?: string;
    appealState?: string;
    appealCreatedAt?: number;
    appealReasonOptions: { reason?: string; label?: string }[];
    appealFormUrl?: string;
    policy?: {
        headline?: string;
        subtitle?: string;
        overview?: string;
        explanation?: string;
        adminDisclaimer?: string;
    };
}
export function makeNewsletterSocket(config: any): {
    executeWMexQuery: (variables: any, queryId: any, dataPath: any) => Promise<any>;
    newsletterCreate: (name: any, description: any) => Promise<{
        id: any;
        owner: undefined;
        name: any;
        creation_time: number;
        description: any;
        invite: any;
        subscribers: number;
        verification: any;
        picture: {
            id: any;
            directPath: any;
        };
        mute_state: any;
    }>;
    newsletterUpdate: (jid: any, updates: any) => Promise<any>;
    newsletterSubscribers: (jid: string, options?: {
        count?: number;
    }) => Promise<{
        id?: string;
        phoneNumber?: string;
        displayName?: string;
        username?: string;
        role?: string;
        followTime?: number;
    }[]>;
    newsletterSubscribed: (options?: {
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
    }) => Promise<any>;
    newsletterMetadata: (type: 'invite' | 'jid', key: string, options?: {
        fetchCreationTime?: boolean;
        fetchFullImage?: boolean;
        fetchViewerMetadata?: boolean;
        fetchPinnedMessages?: boolean;
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
    }) => Promise<any>;
    newsletterFollow: (jid: any) => Promise<any>;
    newsletterUnfollow: (jid: any) => Promise<any>;
    newsletterUpdateUserSetting: (jid: string, type: 'ADMIN_NOTIFICATIONS' | 'FOLLOWER_NOTIFICATIONS', value: boolean) => Promise<{
        id: string;
        state?: string;
    }>;
    newsletterMute: (jid: any) => Promise<any>;
    newsletterUnmute: (jid: any) => Promise<any>;
    newsletterUpdateName: (jid: any, name: any) => Promise<any>;
    newsletterUpdateReactions: (jid: string, setting: 'ALL' | 'BASIC' | 'NONE' | 'BLOCKLIST') => Promise<any>;
    newsletterUpdateDescription: (jid: any, description: any) => Promise<any>;
    newsletterUpdatePicture: (jid: any, content: any) => Promise<any>;
    newsletterRemovePicture: (jid: any) => Promise<any>;
    newsletterReactMessage: (jid: any, serverId: any, reaction: any) => Promise<void>;
    newsletterFetchMessages: (type: any, key: any, count?: number, after?: any, before?: any) => Promise<{
        [k: string]: any;
    }[]>;
    newsletterFetchMessageUpdates: (jid: string, options?: {
        count?: number;
        since?: number;
        before?: string | number;
        after?: string | number;
    }) => Promise<{
        jid: string;
        messages: { [k: string]: any }[];
    }>;
    newsletterQuestionResponses: (jid: string, serverId: string | number, options?: {
        count?: number;
        before?: string;
        filter?: 'contacts' | 'replied' | 'starred';
        searchText?: string;
    }) => Promise<{
        jid: string;
        serverId: number;
        responses: {
            id?: string;
            t?: number;
            isSender: boolean;
            responseServerId?: string;
            sender: {
                lid?: string;
                notifyName?: string;
                pictureDirectPath?: string;
            };
            replied: boolean;
            starred: boolean;
            message?: any;
        }[];
    }>;
    newsletterMyAddOns: (options?: {
        limit?: number;
        jid?: string;
    }) => Promise<NewsletterAddOnGroup[]>;
    newsletterStatusMyAddOns: (options?: {
        limit?: number;
        jid?: string;
    }) => Promise<NewsletterAddOnGroup[]>;
    subscribeNewsletterUpdates: (jid: any) => Promise<{
        duration: any;
    } | null>;
    newsletterAdminCount: (jid: any) => Promise<any>;
    newsletterChangeOwner: (jid: any, newOwnerJid: any) => Promise<void>;
    newsletterDemote: (jid: any, userJid: any) => Promise<void>;
    newsletterDelete: (jid: any) => Promise<void>;
    newsletterAdminCapabilities: (jid: string) => Promise<string[]>;
    newsletterEnforcements: (jid: string, locale?: string) => Promise<{
        adminProfiles: NewsletterEnforcement[];
        profilePictureDeletions: NewsletterEnforcement[];
        suspensions: NewsletterEnforcement[];
        violatingMessages: NewsletterEnforcement[];
        geoSuspensions: NewsletterEnforcement[];
    }>;
    newsletterReports: (locale?: string) => Promise<any[]>;
    newsletterAppealReport: (reportId: string | number, reason: string) => Promise<any>;
    newsletterCanPostStatus: (jid: string) => Promise<{
        canPost: boolean;
        canPostMusic: boolean;
        capabilities: string[];
    }>;
    newsletterAdminInfo: (jid: string) => Promise<{
        id: string;
        adminCount: number;
        adminProfile?: {
            id?: string;
            name?: string;
            picture?: {
                id?: string;
                directPath?: string;
            };
        };
        adminProfilesEnabled: boolean;
    }>;
    newsletterPollVoters: (jid: string, serverId: string | number, options?: {
        limit?: number;
        voteHash?: string;
    }) => Promise<any>;
    newsletterReactionSenders: (jid: string, serverId: string | number) => Promise<any>;
    newsletterPinMessages: (jid: string, serverIds: (string | number)[] | string | number) => Promise<any>;
    newsletterUnpinMessages: (jid: string, serverIds: (string | number)[] | string | number) => Promise<any>;
    newsletterLabelAiContent: (jid: string, serverId: string | number, messageType?: 'MESSAGE' | 'STATUS') => Promise<any>;
    newsletterLabelPaidPartnership: (jid: string, serverId: string | number, messageType?: 'MESSAGE' | 'STATUS') => Promise<any>;
    newsletterCreateAdminInvite: (jid: string, userJid: string) => Promise<any>;
    newsletterRevokeAdminInvite: (jid: string, userJid: string) => Promise<any>;
    newsletterAcceptAdminInvite: (jid: string) => Promise<any>;
    newsletterDirectoryList: (options?: {
        view?: 'RECOMMENDED' | 'NEW' | 'POPULAR' | 'FEATURED' | 'TRENDING';
        categories?: string[];
        countryCodes?: string[];
        limit?: number;
        cursorToken?: string;
        fetchStatusMetadata?: boolean;
    }) => Promise<any>;
    newsletterDirectorySearch: (searchText: string, options?: {
        categories?: string[];
        limit?: number;
        cursorToken?: string;
        fetchStatusMetadata?: boolean;
    }) => Promise<any>;
    newsletterDirectoryCategories: (options?: {
        categories?: string[];
        countryCode?: string;
        perCategoryLimit?: number;
        fetchStatusMetadata?: boolean;
    }) => Promise<any>;
    newsletterSendPollVote: (jid: string, parentServerId: string | number, options: string[] | string) => Promise<{
        id: string;
    }>;
    newsletterInsights: (jid: string, options?: {
        metrics?: string[];
    }) => Promise<any>;
    newsletterFollowers: (jid: string, options?: {
        count?: number;
    }) => Promise<any>;
    newsletterPendingAdminInvites: (jid: string) => Promise<{
        id?: string;
        phoneNumber?: string;
    }[]>;
    newsletterQuestionResponseState: (jid: string, serverId: string | number, responseServerId: string | number, state: 'HIDDEN' | 'VISIBLE') => Promise<any>;
    newsletterRecommended: (options?: {
        limit?: number;
        countryCodes?: string[];
        fetchStatusMetadata?: boolean;
    }) => Promise<any>;
    newsletterSimilar: (jid: string, options?: {
        limit?: number;
        countryCodes?: string[];
        fetchStatusMetadata?: boolean;
    }) => Promise<any>;
    groupQuery: (jid: any, type: any, content: any) => Promise<any>;
    groupMetadata: (jid: any) => Promise<{
        id: any;
        notify: any;
        addressingMode: any;
        subject: any;
        subjectOwner: any;
        subjectOwnerPn: any;
        subjectOwnerUsername: any;
        subjectTime: number;
        size: any;
        creation: number;
        owner: string | undefined;
        ownerPn: string | undefined;
        ownerUsername: any;
        owner_country_code: any;
        desc: any;
        descId: any;
        descOwner: string | undefined;
        descOwnerPn: string | undefined;
        descOwnerUsername: any;
        descTime: number | undefined;
        linkedParent: any;
        restrict: boolean;
        announce: boolean;
        isCommunity: boolean;
        isCommunityAnnounce: boolean;
        joinApprovalMode: boolean;
        memberAddMode: boolean;
        participants: any;
        ephemeralDuration: number | undefined;
    }>;
    groupCreate: (subject: any, participants: any) => Promise<{
        id: any;
        notify: any;
        addressingMode: any;
        subject: any;
        subjectOwner: any;
        subjectOwnerPn: any;
        subjectOwnerUsername: any;
        subjectTime: number;
        size: any;
        creation: number;
        owner: string | undefined;
        ownerPn: string | undefined;
        ownerUsername: any;
        owner_country_code: any;
        desc: any;
        descId: any;
        descOwner: string | undefined;
        descOwnerPn: string | undefined;
        descOwnerUsername: any;
        descTime: number | undefined;
        linkedParent: any;
        restrict: boolean;
        announce: boolean;
        isCommunity: boolean;
        isCommunityAnnounce: boolean;
        joinApprovalMode: boolean;
        memberAddMode: boolean;
        participants: any;
        ephemeralDuration: number | undefined;
    }>;
    groupLeave: (id: any) => Promise<void>;
    groupUpdateSubject: (jid: any, subject: any) => Promise<void>;
    groupRequestParticipantsList: (jid: any) => Promise<any>;
    groupRequestParticipantsUpdate: (jid: any, participants: any, action: any) => Promise<any>;
    groupParticipantsUpdate: (jid: any, participants: any, action: any) => Promise<any>;
    groupUpdateDescription: (jid: any, description: any) => Promise<void>;
    groupInviteCode: (jid: any) => Promise<any>;
    groupRevokeInvite: (jid: any) => Promise<any>;
    groupAcceptInvite: (code: any) => Promise<any>;
    groupRevokeInviteV4: (groupJid: any, invitedJid: any) => Promise<boolean>;
    groupAcceptInviteV4: (...args: any[]) => Promise<any>;
    groupGetInviteInfo: (code: any) => Promise<{
        id: any;
        notify: any;
        addressingMode: any;
        subject: any;
        subjectOwner: any;
        subjectOwnerPn: any;
        subjectOwnerUsername: any;
        subjectTime: number;
        size: any;
        creation: number;
        owner: string | undefined;
        ownerPn: string | undefined;
        ownerUsername: any;
        owner_country_code: any;
        desc: any;
        descId: any;
        descOwner: string | undefined;
        descOwnerPn: string | undefined;
        descOwnerUsername: any;
        descTime: number | undefined;
        linkedParent: any;
        restrict: boolean;
        announce: boolean;
        isCommunity: boolean;
        isCommunityAnnounce: boolean;
        joinApprovalMode: boolean;
        memberAddMode: boolean;
        participants: any;
        ephemeralDuration: number | undefined;
    }>;
    groupToggleEphemeral: (jid: any, ephemeralExpiration: any) => Promise<void>;
    groupSettingUpdate: (jid: any, setting: any) => Promise<void>;
    groupMemberAddMode: (jid: any, mode: any) => Promise<void>;
    groupJoinApprovalMode: (jid: any, mode: any) => Promise<void>;
    groupFetchAllParticipating: () => Promise<{}>;
    findUserId: (pnLid: any) => Promise<{
        lid: undefined;
        phoneNumber: undefined;
    }>;
    serverProps: {
        privacyTokenOn1to1: boolean;
        profilePicPrivacyToken: boolean;
        lidTrustedTokenIssueToLid: boolean;
    };
    createCallLink: (type: any, event: any, timeoutMs: any) => Promise<any>;
    getBotListV2: () => Promise<{
        jid: any;
        personaId: any;
    }[]>;
    messageMutex: {
        mutex(code: any): any;
    };
    receiptMutex: {
        mutex(code: any): any;
    };
    appStatePatchMutex: {
        mutex(code: any): any;
    };
    notificationMutex: {
        mutex(code: any): any;
    };
    fetchPrivacySettings: (force?: boolean) => Promise<any>;
    upsertMessage: (...args: any[]) => Promise<any>;
    appPatch: (patchCreate: any) => Promise<void>;
    sendPresenceUpdate: (type: any, toJid: any) => Promise<void>;
    presenceSubscribe: (toJid: any) => Promise<void>;
    profilePictureUrl: (jid: any, type?: string, timeoutMs?: number, shouldIncludeTcToken?: boolean) => Promise<any>;
    fetchBlocklist: () => Promise<any>;
    fetchStatus: (...jids: any[]) => Promise<any>;
    fetchDisappearingDuration: (...jids: any[]) => Promise<any>;
    updateProfilePicture: (jid: any, content: any, dimensions: any) => Promise<void>;
    removeProfilePicture: (jid: any) => Promise<void>;
    updateProfileStatus: (status: any) => Promise<void>;
    updateProfileName: (name: any) => Promise<void>;
    updateBlockStatus: (jid: any, action: any) => Promise<void>;
    reportSpam: (jid: string, options?: {
        flow?: string;
        source?: string;
        subject?: string;
        isKnownChat?: boolean;
    }) => Promise<{
        jid: string;
        flow: string;
        reported: true;
        node: any;
    }>;
    updateDisableLinkPreviewsPrivacy: (isPreviewsDisabled: any) => Promise<void>;
    updateCallPrivacy: (value: any) => Promise<void>;
    updateMessagesPrivacy: (value: any) => Promise<void>;
    updateLastSeenPrivacy: (value: any) => Promise<void>;
    updateOnlinePrivacy: (value: any) => Promise<void>;
    updateProfilePicturePrivacy: (value: any) => Promise<void>;
    updateStatusPrivacy: (value: any) => Promise<void>;
    updateReadReceiptsPrivacy: (value: any) => Promise<void>;
    updateGroupsAddPrivacy: (value: any) => Promise<void>;
    updateDefaultDisappearingMode: (duration: any) => Promise<void>;
    getBusinessProfile: (jid: any) => Promise<{
        wid: any;
        address: any;
        description: any;
        website: any[];
        email: any;
        category: any;
        business_hours: {
            timezone: any;
            business_config: any;
        };
    } | undefined>;
    resyncAppState: (...args: any[]) => Promise<any>;
    chatModify: (mod: any, jid: any) => Promise<void>;
    cleanDirtyBits: (type: any, fromTimestamp: any) => Promise<void>;
    addOrEditContact: (jid: any, contact: any) => Promise<void>;
    removeContact: (jid: any) => Promise<void>;
    placeholderResendCache: any;
    addLabel: (jid: any, labels: any) => Promise<void>;
    addChatLabel: (jid: any, labelId: any) => Promise<void>;
    removeChatLabel: (jid: any, labelId: any) => Promise<void>;
    addMessageLabel: (jid: any, messageId: any, labelId: any) => Promise<void>;
    removeMessageLabel: (jid: any, messageId: any, labelId: any) => Promise<void>;
    star: (jid: any, messages: any, star: any) => Promise<void>;
    addOrEditQuickReply: (quickReply: any) => Promise<void>;
    removeQuickReply: (timestamp: any) => Promise<void>;
    type: string;
    ws: import("./Client/websocket.js").WebSocketClient;
    ev: {
        process(handler: any): () => void;
        emit(event: any, evData: any): any;
        isBuffering(): boolean;
        buffer: () => void;
        flush: () => boolean;
        createBufferedFunction(work: any): (...args: any[]) => Promise<any>;
        on: (...args: any[]) => any;
        off: (...args: any[]) => any;
        removeAllListeners: (...args: any[]) => any;
        destroy(): void;
    };
    authState: {
        creds: any;
        keys: {
            get: (type: any, ids: any) => Promise<any>;
            set: (data: any) => Promise<void>;
            isInTransaction: () => boolean;
            transaction: (work: any, key: any) => Promise<any>;
        };
    };
    signalRepository: any;
    user: any;
    generateMessageTag: () => string;
    query: (node: any, timeoutMs: any) => Promise<any>;
    waitForMessage: (msgId: any, timeoutMs?: any) => Promise<any>;
    waitForSocketOpen: () => Promise<void>;
    sendRawMessage: (data: any) => Promise<void>;
    sendNode: (frame: any) => Promise<void>;
    logout: (msg: any) => Promise<void>;
    end: (error: any) => Promise<void>;
    registerSocketEndHandler: (handler: any) => void;
    onUnexpectedError: (err: any, msg: any) => void;
    uploadPreKeys: (count?: number) => Promise<void>;
    uploadPreKeysToServerIfRequired: () => Promise<void>;
    digestKeyBundle: () => Promise<void>;
    rotateSignedPreKey: () => Promise<void>;
    requestPairingCode: (phoneNumber: any, customPairingCode: any) => Promise<any>;
    updateServerTimeOffset: ({ attrs }: {
        attrs: any;
    }) => void;
    sendUnifiedSession: () => Promise<void>;
    wamBuffer: import("../index.js").BinaryInfo;
    waitForConnectionUpdate: (check: any, timeoutMs: any) => Promise<void>;
    sendWAMBuffer: (wamBuffer: any) => Promise<any>;
    executeUSyncQuery: (usyncQuery: any) => Promise<any>;
    onWhatsApp: (...phoneNumber: any[]) => Promise<any>;
    onWhatsAppUsername: (...usernames: any[]) => Promise<any>;
    getUsernames: (...jids: any[]) => Promise<any>;
    fetchAccountReachoutTimelock: () => Promise<{
        isActive: boolean;
        timeEnforcementEnds: Date | undefined;
        enforcementType: any;
    }>;
    fetchNewChatMessageCap: () => Promise<any>;
};
