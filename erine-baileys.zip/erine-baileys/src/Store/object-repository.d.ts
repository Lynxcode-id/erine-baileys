/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class ObjectRepository {
    constructor(entities?: {});
    entityMap: Map<string, any>;
    findById(id: any): any;
    findAll(): any[];
    upsertById(id: any, entity: any): Map<string, any>;
    deleteById(id: any): boolean;
    count(): number;
    toJSON(): any[];
}
