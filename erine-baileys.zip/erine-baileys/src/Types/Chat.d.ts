/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export const ALL_WA_PATCH_NAMES: string[];
export const SPAM_FLOWS: Readonly<Record<string, string>>;
