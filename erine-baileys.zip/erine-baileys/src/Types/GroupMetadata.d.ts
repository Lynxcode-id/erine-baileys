/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export declare enum GroupHistoryToggleMode {
    DEFAULT = 0,
    ON = 1,
    OFF = 2
}
