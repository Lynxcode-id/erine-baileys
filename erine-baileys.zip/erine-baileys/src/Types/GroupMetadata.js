/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export var GroupHistoryToggleMode;
(function (GroupHistoryToggleMode) {
    GroupHistoryToggleMode[GroupHistoryToggleMode["DEFAULT"] = 0] = "DEFAULT";
    GroupHistoryToggleMode[GroupHistoryToggleMode["ON"] = 1] = "ON";
    GroupHistoryToggleMode[GroupHistoryToggleMode["OFF"] = 2] = "OFF";
})(GroupHistoryToggleMode || (GroupHistoryToggleMode = {}));
