/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */

export var LabelAssociationType;
(function (LabelAssociationType) {
    LabelAssociationType["Chat"] = "label_jid";
    LabelAssociationType["Message"] = "label_message";
})(LabelAssociationType || (LabelAssociationType = {}));
