/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export const SyncState: any;
export const ReachoutTimelockEnforcementType: any;
export const NewChatMessageCappingStatusType: any;
export const NewChatMessageCappingMVStatusType: any;
export const NewChatMessageCappingOTEStatusType: any;
