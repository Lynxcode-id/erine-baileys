/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export const CompanionWebClientType: any;
export function getCompanionWebClientType([os, browserName]: [any, any]): any;
export function getCompanionPlatformId(browser: any): any;
export function buildPairingQRData(ref: any, noiseKeyB64: any, identityKeyB64: any, advB64: any, browser: any): string;
