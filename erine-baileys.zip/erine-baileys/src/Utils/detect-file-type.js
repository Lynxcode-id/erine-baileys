/* Erine Baileys — by Lynx decode (github.com/Lynxcode-id).
 * Magic-byte file type sniffing, written for Erine Baileys so that media without an explicit
 * `mimetype` gets detected from its content. The behaviour mirrors the mimetype auto-detection
 * introduced in itsliaaa/baileys (Lia Wynn) v0.5.0; the implementation here has no native dependency.
 * Upstream notices and licenses are preserved in LICENSE and NOTICE.md.
 */
import { open } from 'fs/promises';

const SNIFF_BYTES = 4100;

const startsWith = (buf, bytes, offset = 0) => {
    if (buf.length < offset + bytes.length) {
        return false;
    }
    for (let i = 0; i < bytes.length; i++) {
        if (buf[offset + i] !== bytes[i]) {
            return false;
        }
    }
    return true;
};

const ascii = (buf, start, end) => buf.subarray(start, end).toString('latin1');

const MP4_BRANDS = {
    'M4A ': { mime: 'audio/mp4', ext: 'm4a' },
    'M4B ': { mime: 'audio/mp4', ext: 'm4b' },
    'qt  ': { mime: 'video/quicktime', ext: 'mov' },
    '3gp4': { mime: 'video/3gpp', ext: '3gp' },
    '3gp5': { mime: 'video/3gpp', ext: '3gp' },
    '3g2a': { mime: 'video/3gpp2', ext: '3g2' },
    'heic': { mime: 'image/heic', ext: 'heic' },
    'heix': { mime: 'image/heic', ext: 'heic' },
    'mif1': { mime: 'image/heif', ext: 'heif' },
    'avif': { mime: 'image/avif', ext: 'avif' }
};

/**
 * Detect the mime type of a buffer from its leading bytes.
 * @returns {{ mime: string, ext: string } | undefined}
 */
export const detectBufferType = (buf) => {
    if (!buf || buf.length < 4) {
        return undefined;
    }
    if (startsWith(buf, [0xff, 0xd8, 0xff])) {
        return { mime: 'image/jpeg', ext: 'jpg' };
    }
    if (startsWith(buf, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) {
        return { mime: 'image/png', ext: 'png' };
    }
    if (ascii(buf, 0, 4) === 'GIF8') {
        return { mime: 'image/gif', ext: 'gif' };
    }
    if (ascii(buf, 0, 4) === 'RIFF' && buf.length >= 12) {
        const kind = ascii(buf, 8, 12);
        if (kind === 'WEBP') {
            return { mime: 'image/webp', ext: 'webp' };
        }
        if (kind === 'WAVE') {
            return { mime: 'audio/wav', ext: 'wav' };
        }
        if (kind === 'AVI ') {
            return { mime: 'video/x-msvideo', ext: 'avi' };
        }
    }
    if (ascii(buf, 0, 2) === 'BM') {
        return { mime: 'image/bmp', ext: 'bmp' };
    }
    if (buf.length >= 12 && ascii(buf, 4, 8) === 'ftyp') {
        const brand = ascii(buf, 8, 12);
        return MP4_BRANDS[brand] ?? { mime: 'video/mp4', ext: 'mp4' };
    }
    if (startsWith(buf, [0x1a, 0x45, 0xdf, 0xa3])) {
        const head = ascii(buf, 0, Math.min(buf.length, 64));
        return head.includes('webm')
            ? { mime: 'video/webm', ext: 'webm' }
            : { mime: 'video/x-matroska', ext: 'mkv' };
    }
    if (ascii(buf, 0, 4) === 'OggS') {
        const head = ascii(buf, 0, Math.min(buf.length, 128));
        if (head.includes('OpusHead')) {
            return { mime: 'audio/ogg; codecs=opus', ext: 'opus' };
        }
        if (head.includes('\x01vorbis')) {
            return { mime: 'audio/ogg', ext: 'ogg' };
        }
        return { mime: 'application/ogg', ext: 'ogx' };
    }
    if (ascii(buf, 0, 3) === 'ID3' || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0 && (buf[1] & 0x06) !== 0)) {
        if (buf[0] === 0xff && (buf[1] & 0xf6) === 0xf0) {
            return { mime: 'audio/aac', ext: 'aac' };
        }
        return { mime: 'audio/mpeg', ext: 'mp3' };
    }
    if (ascii(buf, 0, 4) === 'fLaC') {
        return { mime: 'audio/flac', ext: 'flac' };
    }
    if (ascii(buf, 0, 5) === '#!AMR') {
        return { mime: 'audio/amr', ext: 'amr' };
    }
    if (ascii(buf, 0, 4) === '%PDF') {
        return { mime: 'application/pdf', ext: 'pdf' };
    }
    if (startsWith(buf, [0x50, 0x4b, 0x03, 0x04])) {
        const head = ascii(buf, 0, buf.length);
        if (head.includes('word/')) {
            return { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ext: 'docx' };
        }
        if (head.includes('xl/')) {
            return { mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ext: 'xlsx' };
        }
        if (head.includes('ppt/')) {
            return { mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', ext: 'pptx' };
        }
        if (head.includes('application/vnd.android.package-archive') || head.includes('AndroidManifest.xml')) {
            return { mime: 'application/vnd.android.package-archive', ext: 'apk' };
        }
        return { mime: 'application/zip', ext: 'zip' };
    }
    if (startsWith(buf, [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07])) {
        return { mime: 'application/vnd.rar', ext: 'rar' };
    }
    if (startsWith(buf, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c])) {
        return { mime: 'application/x-7z-compressed', ext: '7z' };
    }
    if (startsWith(buf, [0x1f, 0x8b])) {
        return { mime: 'application/gzip', ext: 'gz' };
    }
    if (startsWith(buf, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1])) {
        return { mime: 'application/x-cfb', ext: 'cfb' };
    }
    return undefined;
};

/**
 * Detect the mime type of a file on disk by reading only its first bytes.
 * Always resolves; `mime` is undefined when the type is not recognised.
 * @returns {Promise<{ mime: string | undefined, ext: string | undefined }>}
 */
export const detectFileType = async (filePath) => {
    let handle;
    try {
        handle = await open(filePath, 'r');
        const buffer = Buffer.alloc(SNIFF_BYTES);
        const { bytesRead } = await handle.read(buffer, 0, SNIFF_BYTES, 0);
        const detected = detectBufferType(buffer.subarray(0, bytesRead));
        return { mime: detected?.mime, ext: detected?.ext };
    }
    catch {
        return { mime: undefined, ext: undefined };
    }
    finally {
        await handle?.close().catch(() => undefined);
    }
};
