/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */

export declare const GROUP_ADDRESSING_MODES: readonly string[]
export declare function isUsableGroupMetadata(metadata: any): boolean
export declare function describeUnusableGroupMetadata(metadata: any): string
