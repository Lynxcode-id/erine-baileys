/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function handleIdentityChange(node: any, ctx: any): Promise<{
    action: string;
    device?: undefined;
    error?: undefined;
} | {
    action: string;
    device: number;
    error?: undefined;
} | {
    action: string;
    error: unknown;
    device?: undefined;
}>;
