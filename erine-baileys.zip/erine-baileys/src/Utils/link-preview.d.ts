/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function getUrlInfo(text: any, opts?: {
    thumbnailWidth: number;
    fetchOpts: {
        timeout: number;
    };
}): Promise<{
    'canonical-url': any;
    'matched-text': any;
    title: any;
    description: any;
    originalThumbnailUrl: any;
} | undefined>;
