/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
import { LTHashAntiTampering } from '@rexxhayanasi/wangcap-id-bridge';

export const LT_HASH_ANTI_TAMPERING = new LTHashAntiTampering();
