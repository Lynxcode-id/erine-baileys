/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function makeMutex(): {
    mutex(code: any): any;
};
export function makeKeyedMutex(): {
    mutex(key: any, task: any): Promise<any>;
};
