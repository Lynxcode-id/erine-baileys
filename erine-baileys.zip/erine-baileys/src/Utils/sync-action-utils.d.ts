/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function processContactAction(action: any, id: any, logger: any): any[];
export function emitSyncActionResults(ev: any, results: any): void;
