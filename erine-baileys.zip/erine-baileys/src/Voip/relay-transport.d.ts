/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export declare class RelayRtcTransport {
    send(data: Uint8Array, ip: string, port: number): void;
    closeAll(): void;
}
export default RelayRtcTransport;
