/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function decompressingIfRequired(buffer: any): Promise<any>;
export function decodeDecompressedBinaryNode(buffer: any, opts: any, indexRef?: {
    index: number;
}): {
    tag: any;
    attrs: {};
    content: any;
};
export function decodeBinaryNode(buff: any): Promise<any>;
