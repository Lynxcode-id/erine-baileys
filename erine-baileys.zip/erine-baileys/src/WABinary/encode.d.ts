/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export function encodeBinaryNode(node: any, opts?: typeof constants, buffer?: number[]): any;
import * as constants from './constants.js';
