/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class BinaryInfo {
    constructor(options = {}) {
        this.protocolVersion = 5;
        this.sequence = 0;
        this.events = [];
        this.buffer = [];
        Object.assign(this, options);
    }
}
