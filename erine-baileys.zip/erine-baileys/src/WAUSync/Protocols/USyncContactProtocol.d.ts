/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class USyncContactProtocol {
    name: string;
    getQueryElement(): {
        tag: string;
        attrs: {};
    };
    getUserElement(user: any): {
        tag: string;
        attrs: {
            type?: undefined;
        };
        content: any;
    } | {
        tag: string;
        attrs: {
            lid?: any;
            pin?: any;
            username: any;
            type?: undefined;
        };
        content?: undefined;
    } | {
        tag: string;
        attrs: {
            type: any;
        };
        content?: undefined;
    } | {
        tag: string;
        attrs: {
            type?: undefined;
        };
        content?: undefined;
    };
    parser(node: any): boolean;
}
