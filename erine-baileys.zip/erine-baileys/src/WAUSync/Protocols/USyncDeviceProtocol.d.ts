/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class USyncDeviceProtocol {
    name: string;
    getQueryElement(): {
        tag: string;
        attrs: {
            version: string;
        };
    };
    getUserElement(): null;
    parser(node: any): {
        deviceList: {
            id: number;
            keyIndex: number;
            isHosted: boolean;
        }[];
        keyIndex: {
            timestamp: number;
            signedKeyIndex: any;
            expectedTimestamp: number | undefined;
        } | undefined;
    };
}
