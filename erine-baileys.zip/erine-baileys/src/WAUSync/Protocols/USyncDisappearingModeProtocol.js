/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
import { assertNodeErrorFree } from '../../WABinary/index.js';
export class USyncDisappearingModeProtocol {
    constructor() {
        this.name = 'disappearing_mode';
    }
    getQueryElement() {
        return {
            tag: 'disappearing_mode',
            attrs: {}
        };
    }
    getUserElement() {
        return null;
    }
    parser(node) {
        if (node.tag === 'disappearing_mode') {
            assertNodeErrorFree(node);
            const duration = +node?.attrs.duration;
            const setAt = new Date(+(node?.attrs.t || 0) * 1000);
            return {
                duration,
                setAt
            };
        }
    }
}
