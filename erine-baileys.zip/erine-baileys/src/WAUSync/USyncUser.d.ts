/* Erine Baileys by Lynx decode (github.com/Lynxcode-id), a fork of Elaina Baileys by rexxhayanasi. Upstream notices and licenses are preserved in LICENSE and NOTICE.md. */
export class USyncUser {
    withId(id: any): this;
    id: any;
    withLid(lid: any): this;
    lid: any;
    withPhone(phone: any): this;
    phone: any;
    withUsername(username: any): this;
    username: any;
    withUsernameKey(usernameKey: any): this;
    usernameKey: any;
    withType(type: any): this;
    type: any;
    withPersonaId(personaId: any): this;
    personaId: any;
}
