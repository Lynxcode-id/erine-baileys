import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { detectBufferType, detectFileType } from '../src/Utils/detect-file-type.js'
import { LANGUAGE_KEYWORDS, LEXER_REGEX } from '../src/Utils/rich-language-keywords.js'

const buf = (...parts) => Buffer.concat(parts.map(p => (typeof p === 'string' ? Buffer.from(p, 'latin1') : Buffer.from(p))))

test('detectBufferType recognises the common WhatsApp media types', () => {
    assert.equal(detectBufferType(buf([0xff, 0xd8, 0xff, 0xe0, 0, 0]))?.mime, 'image/jpeg')
    assert.equal(detectBufferType(buf([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]))?.mime, 'image/png')
    assert.equal(detectBufferType(buf('RIFF', [0, 0, 0, 0], 'WEBP'))?.mime, 'image/webp')
    assert.equal(detectBufferType(buf([0, 0, 0, 24], 'ftypisom'))?.mime, 'video/mp4')
    assert.equal(detectBufferType(buf([0, 0, 0, 24], 'ftypM4A '))?.mime, 'audio/mp4')
    assert.equal(detectBufferType(buf('OggS', Buffer.alloc(24), 'OpusHead'))?.mime, 'audio/ogg; codecs=opus')
    assert.equal(detectBufferType(buf('ID3', [4, 0, 0]))?.mime, 'audio/mpeg')
    assert.equal(detectBufferType(buf('%PDF-1.7'))?.mime, 'application/pdf')
    assert.equal(detectBufferType(buf([0x50, 0x4b, 3, 4], '....word/document.xml'))?.mime, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    assert.equal(detectBufferType(buf('hello world')), undefined)
})

test('detectFileType reads from disk and never throws', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'erine-detect-'))
    try {
        const file = join(dir, 'x.bin')
        await writeFile(file, buf([0xff, 0xd8, 0xff, 0xe0, 0, 0]))
        assert.deepEqual(await detectFileType(file), { mime: 'image/jpeg', ext: 'jpg' })
        assert.deepEqual(await detectFileType(join(dir, 'missing.bin')), { mime: undefined, ext: undefined })
    }
    finally {
        await rm(dir, { recursive: true, force: true })
    }
})

test('lexer data from the Lia port is intact', () => {
    assert.ok(LANGUAGE_KEYWORDS.javascript.has('const'))
    assert.equal(LANGUAGE_KEYWORDS.js, LANGUAGE_KEYWORDS.javascript)
    assert.ok(LANGUAGE_KEYWORDS.python.has('def'))
    LEXER_REGEX.lastIndex = 0
    assert.ok(LEXER_REGEX.exec('const a = 1') !== null)
})
